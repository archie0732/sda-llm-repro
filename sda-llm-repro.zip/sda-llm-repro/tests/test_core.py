import json
import math
import os
import random

import cv2
import numpy as np
import pytest
from PIL import Image

from sdarepro import arkit
from sdarepro.annotate import assign_ids, compute_view_boxes
from sdarepro.dedup import Detection, backproject, dedup_geometric, dedup_none, evaluate_clusters, match_to_gt
from sdarepro.dialogue import GeoContext, build_constraints, gen_type_a, gen_type_b, target_facts
from sdarepro.geometry import (camera_yaw_deg, estimate_up_axis, project_box, traj_line_to_pose,
                               world_to_camera)
from sdarepro.metrics import jaccard, score_type_a, score_type_b
from sdarepro.prepare import load_prepared, prepare_scene
from sdarepro.prompts import object_table
from sdarepro.runner import context_blocks, run_active, run_dialogue
from sdarepro.synth import camera_pose, synthetic_room
from sdarepro.views import select_views
from sdarepro.vlm import ScriptedClient, ids_from, parse_json


# ---------------------------------------------------------------- geometry
def test_traj_matches_official_formula():
    pose = camera_pose(np.array([0.3, -0.2, 1.3]), 37.0)
    w2c = np.linalg.inv(pose)
    aa = cv2.Rodrigues(w2c[:3, :3])[0].ravel()
    line = f"12.5 {aa[0]} {aa[1]} {aa[2]} {w2c[0, 3]} {w2c[1, 3]} {w2c[2, 3]}"
    ts, got = traj_line_to_pose(line)
    assert ts == 12.5
    assert np.allclose(got, pose, atol=1e-6)


def test_projection_and_heading():
    scene = synthetic_room()
    f0 = scene.frames[0]            # yaw 0 looks along +x, where the table is
    table = scene.objects[0]
    box = project_box(table, f0)
    assert box is not None
    cx = (box[0] + box[2]) / 2
    assert abs(cx - 320) < 40
    assert estimate_up_axis([f.pose for f in scene.frames]) == 2
    assert abs(camera_yaw_deg(scene.frames[18].pose, 2) - 90) < 1e-6   # 18 * 5 deg
    fridge = scene.objects[7]       # at -y, behind the camera for yaw 0? no: at 270 deg
    assert project_box(fridge, f0) is None


def test_view_selection_covers_all_bins():
    sel = select_views(synthetic_room())
    assert sel.coverage == 8
    heads = sorted(camera_yaw_deg(f.pose, 2) for f in sel.frames)
    gaps = np.diff(heads + [heads[0] + 360])
    assert np.all(np.abs(gaps - 45) < 12)


# ---------------------------------------------------------------- dialogues
def _ctx():
    scene = synthetic_room()
    sel = select_views(scene)
    assign_ids(scene, sel.station_xy, sel.station_heading_deg)
    return scene, sel, GeoContext(objects=scene.objects, up_axis=2, station_xy=sel.station_xy,
                                  heading_deg=sel.station_heading_deg)


def test_type_b_dialogues_narrow_to_target():
    scene, sel, ctx = _ctx()
    rng = random.Random(1)
    chairs = [o for o in ctx.objects if o.label == "chair"]
    made = 0
    for t in chairs:
        d = gen_type_b(ctx, t, "d", "s", rng)
        if d is None:
            continue
        made += 1
        sizes = [len(tu.gt_set) for tu in d.turns]
        assert sizes[0] == len(chairs)
        assert all(a > b for a, b in zip(sizes, sizes[1:])), sizes
        assert d.turns[-1].gt_set == [t.obj_id]
        assert all(t.obj_id in tu.gt_set for tu in d.turns)
    assert made >= 3


def test_type_a_dialogues_are_true_and_unique():
    scene, sel, ctx = _ctx()
    rng = random.Random(2)
    made = 0
    for t in [o for o in ctx.objects if o.label == "chair"]:
        d = gen_type_a(ctx, t, "d", "s", rng)
        if d is None:
            continue
        made += 1
        assert all(tu.gt_set == [t.obj_id] for tu in d.turns)
        assert d.turns[0].text.startswith("Help me find the chair")
    assert made >= 2


def test_superlative_requires_gap():
    scene, sel, ctx = _ctx()
    ctx.superlative_gap = 100.0  # impossible gap -> no superlative is usable
    t = next(o for o in ctx.objects if o.label == "chair")
    S = [o for o in ctx.objects if o.label == "chair"]
    for c in build_constraints(ctx, t):
        if c.kind in ("closest_to", "farthest_from", "closest_to_robot", "farthest_from_robot"):
            assert c.apply(S) is None


def test_facts_never_contain_ids():
    scene, sel, ctx = _ctx()
    t = next(o for o in ctx.objects if o.label == "chair")
    facts = " ".join(target_facts(ctx, t))
    assert "#" not in facts


def test_object_table_robot_frame():
    scene, sel, ctx = _ctx()
    ctx.heading_deg = 0.0
    ctx.station_xy = np.zeros(2)
    row = [r for r in object_table(ctx).splitlines() if "| table |" in r][0]
    x, y = float(row.split("|")[2]), float(row.split("|")[3])
    assert abs(x - 2.6) < 1e-6 and abs(y) < 1e-6


# ---------------------------------------------------------------- metrics
def test_metrics_values():
    assert jaccard([1, 2], [2, 3]) == pytest.approx(1 / 3)
    a = score_type_a(1, [[1, 2], [1]], k=4)
    assert a["SR"] == pytest.approx(0.75) and a["AS"] == pytest.approx(0.75) and a["T_A"] == pytest.approx(0.75)
    assert score_type_a(1, [[2]], k=4)["T_A"] == 0.0
    b = score_type_b(3, [[1, 2, 3], [3]], [[1, 2, 3, 4], [3]])
    assert b["AR"] == 1.0 and b["NS"] == pytest.approx((0.75 + 1) / 2)
    assert b["T_B"] == pytest.approx(0.6 + 0.4 * 0.875)


def test_parse_json_tolerates_fences():
    p = parse_json('```json\n{"candidate_ids": ["#3", 5], "count": 2}\n```')
    assert ids_from(p) == [3, 5]
    assert parse_json("no json here") is None


# ---------------------------------------------------------------- pipeline
@pytest.fixture()
def prepared(tmp_path):
    ps = prepare_scene(synthetic_room(), str(tmp_path), use_depth=False, dialogues_per_type=3)
    assert ps is not None
    return tmp_path, ps


def test_prepare_and_reload(prepared):
    root, ps = prepared
    again = load_prepared(os.path.join(root, ps.scene_id))
    assert len(again.images_annot) == 8
    assert again.dialogues == ps.dialogues
    assert {o.obj_id for o in again.ctx.objects} == {o.obj_id for o in ps.ctx.objects}


def test_context_blocks_per_condition(prepared):
    _, ps = prepared
    n_img = lambda blocks: sum(b["type"] == "image" for b in blocks)
    assert n_img(context_blocks("multi_image", ps)[1]) == 8
    assert n_img(context_blocks("grid", ps)[1]) == 1
    sys_t, blocks_t = context_blocks("text_only", ps)
    assert n_img(blocks_t) == 0 and "Detected objects" in blocks_t[-1]["text"]
    assert n_img(context_blocks("multi_image_text", ps)[1]) == 8


def test_oracle_client_scores_perfectly(prepared):
    _, ps = prepared
    for dlg in ps.dialogues:
        replies = [{"candidate_ids": t["gt_set"], "count": len(t["gt_set"])} for t in dlg["turns"]]
        rec = run_dialogue(ScriptedClient(replies), "multi_image", ps, dlg)
        key = "T_A" if dlg["dtype"] == "A" else "T_B"
        if dlg["dtype"] == "A":
            assert rec["alpha"] == 1 and rec[key] == pytest.approx(1.0)
        else:
            assert rec["found"] and rec["NS"] == pytest.approx(1.0) and rec[key] == pytest.approx(1.0)


def test_images_sent_only_once(prepared):
    _, ps = prepared
    dlg = next(d for d in ps.dialogues if d["dtype"] == "B")
    replies = [{"candidate_ids": t["gt_set"]} for t in dlg["turns"]]
    client = ScriptedClient(replies)
    run_dialogue(client, "multi_image", ps, dlg)
    last_msgs = client.calls[-1][1]
    imgs = sum(b["type"] == "image" for m in last_msgs for b in m["content"])
    assert imgs == 8


def test_active_mode_loop(prepared):
    _, ps = prepared
    dlg = next(d for d in ps.dialogues if d["dtype"] == "B")
    robot = ScriptedClient([{"action": "ask", "question": "Near what?", "candidate_ids": dlg["turns"][0]["gt_set"]},
                            {"action": "go", "candidate_ids": [dlg["target"]]}])
    user = ScriptedClient([{"answer": "near the sofa"}])
    rec = run_active(robot, user, ps, dlg)
    assert rec["found"] and rec["robot_turns"] == 2
    assert "Facts:" in user.calls[0][0]


# ---------------------------------------------------------------- dedup
def test_geometric_dedup_on_synthetic_depth():
    scene = synthetic_room()
    sel = select_views(scene)
    assign_ids(scene, sel.station_xy, sel.station_heading_deg)
    labels = {o.obj_id: o.label for o in scene.objects}
    vbs = compute_view_boxes(scene.objects, sel.frames, use_depth=False)
    dets = []
    for vi, vb in enumerate(vbs):
        f = vb.frame
        f.depth_K = f.K.copy()
        depth = np.zeros((f.height, f.width), np.float32)
        for oid, b in vb.boxes.items():   # paint each object's centre depth into its box
            z = world_to_camera(scene.by_id(oid).center[None], f.pose)[0, 2]
            x0, y0, x1, y1 = [int(v) for v in b]
            region = depth[y0:y1 + 1, x0:x1 + 1]
            region[(region == 0) | (region > z)] = z
        for oid, b in vb.boxes.items():
            d = Detection(view=vi, label=labels[oid], box=b)
            d.world = backproject(d, f, depth)
            dets.append(d)
    match_to_gt(dets, [vb.boxes for vb in vbs], labels)
    geo = evaluate_clusters(dets, dedup_geometric(dets, tau=0.6))
    none = evaluate_clusters(dets, dedup_none(dets))
    assert none["recall"] == 0.0 and none["count_error"] > 0
    assert geo["recall"] > 0.8 and geo["precision"] > 0.9


# ---------------------------------------------------------------- ARKit loader on fake files
def test_arkit_loader_on_fake_layout(tmp_path):
    vid = "41069021"
    root = tmp_path / vid
    (root / "vga_wide").mkdir(parents=True)
    (root / "vga_wide_intrinsics").mkdir()
    scene = synthetic_room(step_deg=45)
    lines = []
    for f in scene.frames:
        ts = f"{f.timestamp + 100:.3f}"
        w2c = np.linalg.inv(f.pose)
        aa = cv2.Rodrigues(w2c[:3, :3])[0].ravel()
        lines.append(f"{ts} {aa[0]} {aa[1]} {aa[2]} {w2c[0, 3]} {w2c[1, 3]} {w2c[2, 3]}")
        Image.new("RGB", (640, 480)).save(root / "vga_wide" / f"{vid}_{ts}.png")
        (root / "vga_wide_intrinsics" / f"{vid}_{ts}.pincam").write_text("640 480 500 500 320 240")
    (root / "lowres_wide.traj").write_text("\n".join(lines))
    ann = {"data": [{"uid": o.uid, "label": o.label, "segments": {"obbAligned": {
        "centroid": o.center.tolist(), "axesLengths": o.size.tolist(),
        "normalizedAxes": o.rotation.ravel().tolist()}}} for o in scene.objects], "skipped": False}
    (root / f"{vid}_3dod_annotation.json").write_text(json.dumps(ann))
    loaded = arkit.load_scene(str(root), frame_stride=1)
    assert len(loaded.frames) == len(scene.frames)
    assert loaded.up_axis == 2
    for a, b in zip(loaded.frames, scene.frames):
        assert np.allclose(a.pose, b.pose, atol=1e-6)
    assert [o.label for o in loaded.objects] == [o.label for o in scene.objects]
